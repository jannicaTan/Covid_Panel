<template>
  <div class="com-page">
    <HotPie></HotPie>
  </div>
</template>

<script>
import HotPie from '@/components/HotPie'
export default {
  components: {
    HotPie
  }
}
</script>

<style>

</style>
