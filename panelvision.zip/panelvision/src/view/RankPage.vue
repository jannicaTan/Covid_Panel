<template>
  <div class="com-page">
    <RankLine></RankLine>
  </div>
</template>

<script>
import RankLine from '@/components/RankLine'
export default {
  components: {
    RankLine
  }
}
</script>

<style>

</style>
