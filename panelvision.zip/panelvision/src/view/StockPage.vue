<template>
  <div class="com-page">
    <StockPie></StockPie>
  </div>
</template>

<script>
import StockPie from '@/components/StockPie'
export default {
  components: {
    StockPie
  }
}
</script>

<style>

</style>
