<template>
  <div class="com-page">
    <TrendLine></TrendLine>
  </div>
</template>

<script>
import TrendLine from '@/components/TrendLine'
export default {
  components: {
    TrendLine
  }
}
</script>

<style>

</style>
