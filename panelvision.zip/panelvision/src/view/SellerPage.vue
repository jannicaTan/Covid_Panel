<template>
<div class="com-page">
  <SellerBar></SellerBar>
</div>
</template>

<script>
import SellerBar from '@/components/SellerBar'
export default {
  components: {
    SellerBar
  }
}
</script>

    SellerBar
<style>

</style>
