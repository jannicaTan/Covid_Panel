<template>
  <div class="com-page">
    <MapChina></MapChina>
  </div>
</template>

<script>
import MapChina from '@/components/MapChina'
export default {
  components: {
    MapChina
  }
}
</script>

<style>

</style>
